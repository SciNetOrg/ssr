#!/bin/sh

ssr="ssr_core"

#root_dir=`pwd`
root_dir="/root/ssr"

cd $root_dir/$ssr/shadowsocks

server_port="xxx"
password="xxx"

method="aes-128-cfb"
O="auth_aes128_md5"
o="tls1.2_ticket_auth"
num_workers=2

nohup python server.py -p $server_port -k $password -m $method -O $O -o $o --workers $num_workers 2>&1 | tee $root_dir/server.log &


# startup
#pos=`cat /etc/rc.local | grep -n "exit 0" | grep -v "#"`
#pos=${pos%:*}

#if [ `cat /etc/rc.local | grep start_server.sh | wc -l` -eq 0 ]
#then
#	sed "$pos i sh $root_dir/start_server.sh" -i /etc/rc.local
#	cat /etc/rc.local
#fi
