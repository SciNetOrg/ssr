1. because of openssl's version, cleanup becomes reset

2. ssr-ubuntu16
origin ssr by breakwa11

manyuser branch

3. ssr-ubuntu18
change `EVP_CIPHER_CTX_cleanup` to `EVP_CIPHER_CTX_reset`

/*
diff --git a/shadowsocks/crypto/openssl.py b/shadowsocks/crypto/openssl.py
index 3775b6c..915cbfe 100644
--- a/shadowsocks/crypto/openssl.py
+++ b/shadowsocks/crypto/openssl.py
@@ -49,7 +49,7 @@ def load_openssl():
     libcrypto.EVP_CipherUpdate.argtypes = (c_void_p, c_void_p, c_void_p,
                                            c_char_p, c_int)
 
-    libcrypto.EVP_CIPHER_CTX_cleanup.argtypes = (c_void_p,)
+    libcrypto.EVP_CIPHER_CTX_reset.argtypes = (c_void_p,)
     libcrypto.EVP_CIPHER_CTX_free.argtypes = (c_void_p,)
     if hasattr(libcrypto, 'OpenSSL_add_all_ciphers'):
         libcrypto.OpenSSL_add_all_ciphers()
@@ -108,7 +108,7 @@ class OpenSSLCrypto(object):
 
     def clean(self):
         if self._ctx:
-            libcrypto.EVP_CIPHER_CTX_cleanup(self._ctx)
+            libcrypto.EVP_CIPHER_CTX_reset(self._ctx)
             libcrypto.EVP_CIPHER_CTX_free(self._ctx)
*/
