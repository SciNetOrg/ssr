ps -ax | grep server.py | awk '{print $1}'
ps -ax | grep server.py | awk '{print $1}' | xargs kill -9
