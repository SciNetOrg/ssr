ssr="ssr_core"

root_dir=`pwd`

cd $root_dir/$ssr/shadowsocks

server_addr="xxx.xxx.com"
server_port="xxx"
local_port="1080"
password="xxx"
method="aes-128-cfb"
O="auth_aes128_md5"
o="tls1.2_ticket_auth"

python local.py -s $server_addr -p $server_port -k $password -m $method -O $O -o $o -b 0.0.0.0 -l $local_port 2>&1 | tee $root_dir/local.log
